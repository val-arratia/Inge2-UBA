from random import randint
from typing import List, Tuple


def crossover(parent1: List[str], parent2: List[str]) -> Tuple[List[str], List[str]]:
    offspring1 = None
    offspring2 = None
    # TODO: COMPLETAR
    if len(parent1) == 0 or len(parent2) == 0:
        offspring1 = parent1
        offspring2 = parent2
    else:
        p = randint(0,min(len(parent1) - 1,len(parent2)-1))
        offspring1 = parent1[:p]+parent2[p:]
        offspring2 = parent2[:p]+parent1[p:]

    return offspring1, offspring2
