from random import choice
from string import printable
from typing import List


def get_random_character():
    # TODO: COMPLETAR
    return ""


def create_test_case() -> str:
    # TODO: COMPLETAR
    return ""


def create_individual() -> List[str]:
    # TODO: COMPLETAR
    return []


def create_population(population_size) -> List[List[str]]:
    population = []
    # TODO: COMPLETAR
    return population
