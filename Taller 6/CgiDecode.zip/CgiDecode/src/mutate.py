from random import choice, randint
from typing import List

from src.create_population import create_test_case, get_random_character


def add_character(test_case: str) -> str:
    # TODO: COMPLETAR
    char = get_random_character()
    test_case = test_case + char
    return test_case


def remove_character(test_case: str) -> str:
    # TODO: COMPLETAR
    idx = randint(0,len(test_case)-1)
    test_case = test_case[:idx] + test_case[idx+1:]
    return test_case


def modify_character(test_case: str) -> str:
    # TODO: COMPLETAR
    idx = randint(0, len(test_case) - 1)
    char = get_random_character()
    test_case[idx] = char
    return test_case


def add_test_case(individual: List[str]) -> List[str]:
    # TODO: COMPLETAR
    test_case = create_test_case()
    individual.append(test_case)
    return individual


def remove_test_case(individual: List[str]) -> List[str]:
    # TODO: COMPLETAR
    idx = randint(0, len(individual)-1)
    individual = individual[:idx] + individual[idx+1:]
    return individual


def modify_test_case(individual: List[str]) -> List[str]:
    # TODO: COMPLETAR
    individual_selected = choice(individual)
    idx = individual.index(individual_selected)
    if len(individual_selected) == 1:
        mutation_list = ["modify","add"]
        mutation = choice(mutation_list)
    elif len(individual_selected)>=10:
        mutation_list = ["modify", "remove"]
        mutation = choice(mutation_list)
    else: #caso 0?
        mutation_list = ["modify","remove","add"]
        mutation = choice(mutation_list)

    if mutation == "modify":
        individual[idx] = modify_character(individual_selected)
    elif mutation == "remove":
        individual[idx] = remove_character(individual_selected)
    else:
        individual[idx] = add_character(individual_selected)

    return individual


def mutate(individual: List[str]) -> List[str]:
    # TODO: COMPLETAR

    mutation_list=["modify","remove","add"]
    mutation = choice(mutation_list)

    if len(individual) == 1:
        mutation_list = ["modify","add"]
        mutation = choice(mutation_list)
    elif len(individual)>=15:
        mutation_list = ["modify", "remove"]
        mutation = choice(mutation_list)
    else: #caso 0?
        mutation_list = ["modify","remove","add"]
        mutation = choice(mutation_list)

    if mutation == "modify":
        individual = modify_test_case(individual)
    elif mutation == "remove":
        individual = remove_test_case(individual)
    else:
        individual = add_test_case(individual)


    return individual

