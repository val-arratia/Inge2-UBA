from typing import List

from src.cgi_decode_instrumented import cgi_decode_instrumented
from src.evaluate_condition import clear_maps


def get_fitness_cgi_decode(test_suite: List[str]) -> float:
    # Borro la información de branch coverage de ejecuciones anteriores
    # Recuerden que los diccionarios true_distances y false_distances son globales
    clear_maps()

    fitness = 0
    # TODO: COMPLETAR
    for s in test_suite:
        cgi_decode_instrumented(s)
    return 0
