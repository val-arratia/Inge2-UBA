from typing import List

from src.cgi_decode_instrumented import cgi_decode_instrumented
from src.evaluate_condition import clear_maps, has_reached_condition, get_true_distance, \
    get_false_distance


def get_fitness_cgi_decode(test_suite: List[str]) -> float:
    # Borro la información de branch coverage de ejecuciones anteriores
    # Recuerden que los diccionarios true_distances y false_distances son globales
    clear_maps()

    fitness = 0
    # TODO: COMPLETAR
    for s in test_suite:
        cgi_decode_instrumented(s)
        fitness += get_fitness_value()
        clear_maps()
    return fitness

def get_fitness_value():
    suma_value = 0
    conditions = [1,2,3,4,5]
    for c in conditions:
        if has_reached_condition(c):
            suma_value += get_true_distance(c) / (get_true_distance(c) + 1)
            suma_value += get_false_distance(c) / (get_false_distance(c) + 1)
        else:
            suma_value += 2

    return suma_value

