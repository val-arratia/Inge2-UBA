#!./venv/bin/python
import unittest
from src.evaluate_condition import evaluate_condition


class TestEvaluateCondition(unittest.TestCase):
 #   def testExample(self):
 #       # TODO COMPLETAR
 #       evaluate_condition(1, "Eq", 10, 20)
 #       self.assertTrue(True)
 #       self.assertFalse(False)
  #      self.assertEqual(True, False)

    def test1(self):
        v = evaluate_condition(1, "Eq", "10", "20")
        self.assertFalse(v)
        v = evaluate_condition(1, "Eq", "20", "20")
        self.assertTrue(v)

        v = evaluate_condition(1, "Ne", "10", "20")
        self.assertTrue(v)
        v = evaluate_condition(1, "Ne", "20", "20")
        self.assertFalse(v)

        v = evaluate_condition(1, "Lt", "10", "20")
        self.assertTrue(v)
        v = evaluate_condition(1, "Lt", "20", "20")
        self.assertFalse(v)

        v = evaluate_condition(1, "Gt", "10", "20")
        self.assertFalse(v)
        v = evaluate_condition(1, "Gt", "30", "20")
        self.assertTrue(v)

        v = evaluate_condition(1, "Le", "10", "20")
        self.assertTrue(v)
        v = evaluate_condition(1, "Le", "30", "20")
        self.assertFalse(v)

        v = evaluate_condition(1, "Ge", "10", "20")
        self.assertFalse(v)
        v = evaluate_condition(1, "Ge", "30", "20")
        self.assertTrue(v)

    def in_Test(self):
        v = evaluate_condition(1, "in" "10", {"Z": 1 })
        self.assertFalse(v)
        v = evaluate_condition(1, "in" "10", {})
        self.assertFalse(v)
        v = evaluate_condition(1, "in","Z", {"Z": 1 })
        self.assertTrue(v)