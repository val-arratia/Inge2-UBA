#!./venv/bin/python
import unittest
from src.cgi_decode import cgi_decode


class TestCgiDecode(unittest.TestCase):
  #  def testExample(self):
  #      # TODO COMPLETAR
  #      cgi_decode("Hello World")
  #      self.assertTrue(True)
  #      self.assertFalse(False)
  #      self.assertEqual(True, False)

    def test1(self):
        s = "6+4"
        t = cgi_decode(s)
        self.assertEqual(t,"6 4")

    def test2(self):
        s = "%44"
        t = cgi_decode(s)
        self.assertEqual(t, "D")

    def test3(self):
        s = "%xx"
        with self.assertRaises(ValueError, msg="Invalid encoding: digit high is not a hex digit"):
            cgi_decode(s)

    def test4(self):
        s = "%4x"
        with self.assertRaises(ValueError, msg="Invalid encoding: digit low is not a hex digit"):
            cgi_decode(s)
