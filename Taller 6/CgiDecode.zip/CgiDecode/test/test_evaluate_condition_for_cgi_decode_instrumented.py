#!./venv/bin/python
import unittest
from src.cgi_decode import cgi_decode
from src.cgi_decode_instrumented import cgi_decode_instrumented
from src.evaluate_condition import clear_maps, get_true_distance, get_false_distance, distances_false, distances_true


class TestEvaluateConditionForCgiDecodeInstrumented(unittest.TestCase):
    def testExample(self):
        # TODO COMPLETAR
        clear_maps()
        string = cgi_decode_instrumented("Hello+World")
        self.assertEqual(string,"Hello World")
        v1 = get_true_distance(1)
        self.assertEqual(v1, 0)

        v1 = get_true_distance(2)
        self.assertEqual(v1, 0)

        v1 = get_true_distance(3)
        self.assertEqual(v1, 35)

        v1 = get_false_distance(1)
        self.assertEqual(v1, 0)
        v1 = get_false_distance(2)
        self.assertEqual(v1, 0)
        v1 = get_false_distance(3)
        self.assertEqual(v1, 0)

        self.assertEqual(cgi_decode("Hello+World"), "Hello World")


