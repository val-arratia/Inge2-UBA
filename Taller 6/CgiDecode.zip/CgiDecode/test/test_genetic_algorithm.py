#!./venv/bin/python
import unittest

from random import seed
from src.genetic_algorithm import GeneticAlgorithm


class TestGeneticAlgorithm(unittest.TestCase):
    def test1(self):
        # TODO COMPLETAR
        seed(1)
        ga = GeneticAlgorithm()
        result = ga.run()
        self.assertEqual(True, False)

    def test2(self):
        # TODO COMPLETAR
        seed(42)
        ga = GeneticAlgorithm()
        best_individual = ga.run()
        num_generations = ga.get_generation()
        branch_coverage = ga.get_fitness_best_individual()

        # Verifica que el algoritmo alcanza 50% de cobertura en un máximo de 500 generaciones
        self.assertLessEqual(num_generations, 500)
        self.assertGreaterEqual(branch_coverage, 0.5)


    def test3(self):
        # TODO COMPLETAR
        seed(123)
        ga = GeneticAlgorithm()
        best_individual = ga.run()
        num_generations = ga.get_generation()
        branch_coverage = ga.get_fitness_best_individual()

        # Verifica que el algoritmo alcanza 75% de cobertura en un máximo de 800 generaciones
        self.assertLessEqual(num_generations, 800)
        self.assertGreaterEqual(branch_coverage, 0.75)