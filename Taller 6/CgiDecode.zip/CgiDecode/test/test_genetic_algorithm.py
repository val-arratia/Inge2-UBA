#!./venv/bin/python
import unittest

from random import seed
from src.genetic_algorithm import GeneticAlgorithm


class TestGeneticAlgorithm(unittest.TestCase):
    def test1(self):
        # TODO COMPLETAR
        seed(10)
        ga = GeneticAlgorithm()
        best_individual = ga.run()

        self.assertLessEqual(ga.get_generation(), 1000)
        self.assertFalse(ga.covered_all_branches(ga.get_fitness_best_individual()))


    def test2(self):
        # TODO COMPLETAR
        seed(200)
        ga = GeneticAlgorithm()
        best_individual = ga.run()

        self.assertLessEqual(ga.get_generation(), 1000)
        self.assertFalse(ga.covered_all_branches(ga.get_fitness_best_individual()))


    def test3(self):
        # TODO COMPLETAR
        seed(10)
        ga = GeneticAlgorithm()
        best_individual = ga.run()
        self.assertLessEqual(ga.get_generation(), 1000)
        self.assertFalse(ga.covered_all_branches(ga.get_fitness_best_individual()))
