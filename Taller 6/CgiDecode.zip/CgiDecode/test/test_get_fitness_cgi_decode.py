#!./venv/bin/python
import unittest

from src.evaluate_condition import distances_false, distances_true
from src.get_fitness_cgi_decode import get_fitness_cgi_decode


class TestGetFitnessCgiDecode(unittest.TestCase):
    def testAA(self):
        # TODO COMPLETAR
        fit = get_fitness_cgi_decode(["%AA"])
        self.assertEqual(fit, 2.357142857142857)

    def testHelloReader(self):
        fit = get_fitness_cgi_decode(["Hello+Reader"])
        self.assertEqual(fit, 4.972222222222222)

    def testEmpty(self):
        fit = get_fitness_cgi_decode([""])
        self.assertEqual(fit, 8.5)

    def testPlus(self):
        fit = get_fitness_cgi_decode(["+"])
        print(distances_false)
        print(distances_true)
        self.assertEqual(fit, 6.5)

    def testOneTestCase(self):
        fit = get_fitness_cgi_decode(["\%1+"])
        self.assertEqual(fit,   2.9404761904761907)

    def testThreeTestCases(self):
        fit = get_fitness_cgi_decode([r"\%1+", r"%+1", r"a+%AA"])
        self.assertEqual(fit, 0)

    def testFiveTestCases(self):
        fit = get_fitness_cgi_decode(["%A", "%", "\%1+", "%+1", "a+%AA"])
        self.assertEqual(fit, 0)


