#!./venv/bin/python
import unittest

from src.evaluate_condition import distances_false, distances_true
from src.get_fitness_cgi_decode import get_fitness_cgi_decode


class TestGetFitnessCgiDecode(unittest.TestCase):
    def testExample(self):
        # TODO COMPLETAR
        fit = get_fitness_cgi_decode(["%AA"])
        self.assertEqual(fit, 2.357142857142857)

    def testExample2(self):
        fit = get_fitness_cgi_decode(["Hello+Reader"])
        self.assertEqual(fit, 4.972222222222222)

    def testExample3(self):
        fit = get_fitness_cgi_decode([""])
        self.assertEqual(fit, 8.5)

    def testExample4(self):
        fit = get_fitness_cgi_decode(["+"])
        print(distances_false)
        print(distances_true)
        self.assertEqual(fit, 6.5)

    def testExample5(self):
        fit = get_fitness_cgi_decode(["%1+", "%+1", "a+%AA"])

        #fit = get_fitness_cgi_decode(["%1+"])
        print(distances_false)
        print(distances_true)
        print(fit)
        self.assertEqual(fit,   0)
    # preguntar sobre este caso


