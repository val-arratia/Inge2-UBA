#!./venv/bin/python
import unittest
from src.evaluate_condition import evaluate_condition


class TestEvaluateCondition(unittest.TestCase):
 #   def testExample(self):
 #       # TODO COMPLETAR
 #       evaluate_condition(1, "Eq", 10, 20)
 #       self.assertTrue(True)
 #       self.assertFalse(False)
  #      self.assertEqual(True, False)

    def testEqualFalse(self):
        v = evaluate_condition(1, "Eq", "10", "20")
        self.assertFalse(v)

    def testEqualTrue(self):
        v = evaluate_condition(2, "Eq", "20", "20")
        self.assertTrue(v)

    def testNotEqualTrue(self):
        v = evaluate_condition(3, "Ne", "10", "20")
        self.assertTrue(v)

    def testNotEqualFalse(self):
        v = evaluate_condition(4, "Ne", "20", "20")
        self.assertFalse(v)

    def testLessThan(self):
        v = evaluate_condition(5, "Lt", "10", "20")
        self.assertTrue(v)

        v = evaluate_condition(6, "Lt", "20", "20")
        self.assertFalse(v)

    def testGreaterThan(self):
        v = evaluate_condition(7, "Gt", "10", "20")
        self.assertFalse(v)

        v = evaluate_condition(8, "Gt", "30", "20")
        self.assertTrue(v)

    def testLessEqual(self):
        v = evaluate_condition(1, "Le", "10", "20")
        self.assertTrue(v)

        v = evaluate_condition(1, "Le", "30", "20")
        self.assertFalse(v)

    def testGreaterEqual(self):
        v = evaluate_condition(1, "Ge", "10", "20")
        self.assertFalse(v)
        v = evaluate_condition(1, "Ge", "30", "20")
        self.assertTrue(v)


    def testEqualFalse(self):
        v = evaluate_condition(1, "Eq", "a", "b")
        self.assertFalse(v)

    def testEqualTrue(self):
        v = evaluate_condition(2, "Eq", "a", "a")
        self.assertTrue(v)

    def testNotEqualTrue(self):
        v = evaluate_condition(3, "Ne", "a", "b")
        self.assertTrue(v)

    def testNotEqualFalse(self):
        v = evaluate_condition(4, "Ne", "a", "a")
        self.assertFalse(v)

    def testLessThan(self):
        v = evaluate_condition(5, "Lt", "a", "c")
        self.assertTrue(v)

        v = evaluate_condition(6, "Lt", "c", "a")
        self.assertFalse(v)

    def testGreaterThan(self):
        v = evaluate_condition(7, "Gt", "a", "c")
        self.assertFalse(v)

        v = evaluate_condition(8, "Gt", "c", "a")
        self.assertTrue(v)

    def testLessEqual(self):
        v = evaluate_condition(1, "Le", "a", "a")
        self.assertTrue(v)

        v = evaluate_condition(1, "Le", "c", "a")
        self.assertFalse(v)

    def testGreaterEqual(self):
        v = evaluate_condition(1, "Ge", "a", "c")
        self.assertFalse(v)
        v = evaluate_condition(1, "Ge", "c", "c")
        self.assertTrue(v)



    def test_in(self):
        v = evaluate_condition(1, "in","1", {"Z": 1 })
        self.assertFalse(v)
        v = evaluate_condition(1, "in","1", {})
        self.assertFalse(v)
        v = evaluate_condition(1, "in","Z", {"Z": 1 })
        self.assertTrue(v)
