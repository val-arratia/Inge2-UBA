#!./venv/bin/python
import unittest

from random import seed
from src.genetic_algorithm import GeneticAlgorithm

# para consultar si estan bien los tests
class TestGeneticAlgorithm(unittest.TestCase):
    def test1(self):
        # TODO COMPLETAR
        seed(10)
        ga = GeneticAlgorithm()
        best_individual = ga.run()
        self.assertEqual( ga.get_generation(), 1000)
        self.assertEqual(ga.get_fitness_best_individual(),5.803571428571429)


    def test2(self):
        # TODO COMPLETAR
        seed(200)
        ga = GeneticAlgorithm()
        best_individual = ga.run()

        self.assertEqual(ga.get_generation(), 1000)
        self.assertEqual(ga.get_fitness_best_individual(),8.0)


    def test3(self):
        # TODO COMPLETAR
        seed(370)
        ga = GeneticAlgorithm()
        best_individual = ga.run()
        self.assertEqual(ga.get_generation(), 1000)
        print(ga.get_fitness_best_individual())
        self.assertFalse(ga.covered_all_branches(ga.get_fitness_best_individual()))
