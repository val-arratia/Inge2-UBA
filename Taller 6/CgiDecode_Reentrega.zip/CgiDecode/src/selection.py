from random import sample
from typing import Tuple


def selection(fitness_by_individual: dict, tournament_size: int) -> Tuple[str, float]:
    """
    fitness_by_individual: Diccionario que contiene a los individuos de la población como keys y su fitness como valores.
    tournament_size: Tamaño del torneo (entero positivo).
    """
    winner = None
    max_fitness = 0
    # TODO: COMPLETAR
    #  (Tournament selection)
    list_keys = list(fitness_by_individual.keys())
    select = sample(list_keys, tournament_size)

    for s in select:
        if fitness_by_individual[s][1] > max_fitness:
            winner = fitness_by_individual[s][0]
            max_fitness = fitness_by_individual[s][1]

    return winner, max_fitness
