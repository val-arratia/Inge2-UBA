import string
from random import choice, randint
from string import printable
from typing import List


def get_random_character():
    # TODO: COMPLETAR
    return choice(string.printable)


def create_test_case() -> str:
    # TODO: COMPLETAR
    str_len = randint(0,10)
    s = ""
    for _ in range(str_len):
        s += get_random_character()
    return s


def create_individual() -> List[str]:
    # TODO: COMPLETAR
    len_ind = randint(1,15)
    list_ind = []
    for _ in range(len_ind):
        list_ind.append(create_test_case())
    return list_ind


def create_population(population_size) -> List[List[str]]:
    population = []
    # TODO: COMPLETAR
    for _ in range(population_size):
        individual = create_individual()
        population.append(individual)

    return population
