package inge2.dataflow.zeroanalysis;

/**
 * This enum represents the possible values of the zero analysis for a variable.
 */
public enum ZeroAbstractValue {

    /**
     * We don't have information about the variable.
     */
    BOTTOM("bottom"),

    /**
     * The variable is not zero.
     */
    NOT_ZERO("not-zero"),

    /**
     * The variable is zero.
     */
    ZERO("zero"),

    /**
     * The variable may be (or not) zero.
     */
    MAYBE_ZERO("maybe-zero");

    /**
     * The name of the ZeroAbstractValue.
     */
    private final String name;

    @Override
    public String toString() {
        return this.name;
    }

    ZeroAbstractValue(String name) {
        this.name = name;
    }

    /**
     * Returns the result of the addition between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the addition.
     */
    public ZeroAbstractValue add(ZeroAbstractValue another) {
        // TODO: IMPLEMENTAR
        if (this == ZeroAbstractValue.BOTTOM || another == ZeroAbstractValue.BOTTOM ) {
            return ZeroAbstractValue.BOTTOM;
        }else if (this == ZeroAbstractValue.ZERO) {
            return another;
        }else if (another == ZeroAbstractValue.ZERO){
            return this;
        }
        //throw new UnsupportedOperationException();
        return ZeroAbstractValue.MAYBE_ZERO;
    }

    /**
     * Returns the result of the division between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the division.
     */
    public ZeroAbstractValue divideBy(ZeroAbstractValue another) {
        // TODO: IMPLEMENTAR
        if (another == ZeroAbstractValue.BOTTOM || another == ZeroAbstractValue.ZERO ) {
            return ZeroAbstractValue.BOTTOM;
        }else if (this == ZeroAbstractValue.ZERO) {
            return ZeroAbstractValue.ZERO;
        }
        //throw new UnsupportedOperationException();
        return ZeroAbstractValue.MAYBE_ZERO;
    }

    /**
     * Returns the result of the multiplication between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the multiplication.
     */
    public ZeroAbstractValue multiplyBy(ZeroAbstractValue another) {
        // TODO: IMPLEMENTAR
        if (this == ZeroAbstractValue.BOTTOM || another == ZeroAbstractValue.BOTTOM ) {
            return ZeroAbstractValue.BOTTOM;
        }else if (this == ZeroAbstractValue.ZERO || another == ZeroAbstractValue.ZERO) {
            return ZeroAbstractValue.ZERO;
        }else if (this == ZeroAbstractValue.NOT_ZERO && another == ZeroAbstractValue.NOT_ZERO){
            return this;
        }
        //throw new UnsupportedOperationException();
        return ZeroAbstractValue.MAYBE_ZERO;
    }

    /**
     * Returns the result of the subtraction between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the subtraction.
     */
    public ZeroAbstractValue subtract(ZeroAbstractValue another) {
        // TODO: IMPLEMENTAR
        if (another == ZeroAbstractValue.BOTTOM || this == ZeroAbstractValue.BOTTOM) {
            return ZeroAbstractValue.BOTTOM;
        }else if (another == ZeroAbstractValue.MAYBE_ZERO) {
            return ZeroAbstractValue.MAYBE_ZERO;
        }else if (another == ZeroAbstractValue.ZERO && this == ZeroAbstractValue.ZERO){
            return ZeroAbstractValue.ZERO ;
        }else if(this == ZeroAbstractValue.NOT_ZERO && another == ZeroAbstractValue.ZERO){
            return ZeroAbstractValue.NOT_ZERO ;
        }else if(this == ZeroAbstractValue.MAYBE_ZERO && another == ZeroAbstractValue.ZERO){
            return ZeroAbstractValue.MAYBE_ZERO ;
        }else if(this == ZeroAbstractValue.ZERO && another == ZeroAbstractValue.NOT_ZERO){
            return ZeroAbstractValue.NOT_ZERO ;
        }else if(this == ZeroAbstractValue.NOT_ZERO && another == ZeroAbstractValue.NOT_ZERO){
            return ZeroAbstractValue.MAYBE_ZERO ;
        }
        //throw new UnsupportedOperationException();
        return ZeroAbstractValue.MAYBE_ZERO;
        //throw new UnsupportedOperationException();
    }

    /**
     * Returns the result of the merge between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the merge.
     */
    public ZeroAbstractValue merge(ZeroAbstractValue another) {
        // TODO: IMPLEMENTAR
        //throw new UnsupportedOperationException();
        if (another == ZeroAbstractValue.BOTTOM && this == ZeroAbstractValue.BOTTOM) {
            return ZeroAbstractValue.BOTTOM;
        }else if (this == ZeroAbstractValue.MAYBE_ZERO ||another == ZeroAbstractValue.MAYBE_ZERO) {
            return ZeroAbstractValue.MAYBE_ZERO;
        }else if (another == ZeroAbstractValue.ZERO && this != ZeroAbstractValue.MAYBE_ZERO){
            return ZeroAbstractValue.ZERO ;
        }else if (this == ZeroAbstractValue.ZERO && another != ZeroAbstractValue.MAYBE_ZERO){
            return ZeroAbstractValue.ZERO ;
        }
        return ZeroAbstractValue.NOT_ZERO ;

    }

}
