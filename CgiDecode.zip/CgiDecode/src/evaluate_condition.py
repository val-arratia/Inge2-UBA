import sys
from asyncio.windows_events import INFINITE
from typing import Dict, Union

# Inicializar mappings globales
distances_true: Dict[int, int] = {}
distances_false: Dict[int, int] = {}


def update_maps(condition_num: int, d_true: int, d_false: int):
    global distances_true, distances_false

    if condition_num in distances_true.keys():
        distances_true[condition_num] = min(
            distances_true[condition_num], d_true)
    else:
        distances_true[condition_num] = d_true

    if condition_num in distances_false.keys():
        distances_false[condition_num] = min(
            distances_false[condition_num], d_false)
    else:
        distances_false[condition_num] = d_false


def clear_maps():
    global distances_true, distances_false
    distances_true.clear()
    distances_false.clear()


def get_true_distance(condition_num: int) -> Union[int, None]:
    global distances_true
    if condition_num in distances_true.keys():
        return distances_true[condition_num]
    else:
        return None


def get_false_distance(condition_num: int) -> Union[int, None]:
    global distances_false
    if condition_num in distances_false.keys():
        return distances_false[condition_num]
    else:
        return None


def has_reached_condition(condition_num: int) -> bool:
    global distances_true, distances_false
    return condition_num in distances_true.keys() or condition_num in distances_false.keys()


def evaluate_condition(condition_num: int, op: str, lhs: Union[str, Dict], rhs: Union[str, Dict]) -> bool:
    # TODO: COMPLETAR
    # r “Eq” (==), “Ne” (!=),
    # “Lt” (<), “Gt” (>), “Le” (<=), “Ge” (>=), “In”
    d_true, d_false = 0,0
    value = 0
    if lhs.isnumeric() and rhs.isnumeric():
        if op == "Eq":
            value = int(lhs) == int(rhs)
            if value:
                d_true = 0
                d_false = 1
            else:
                d_true = abs(int(lhs) - int(rhs))
        if op == "Ne":
            value = int(lhs) == int(rhs)
            if value:
                d_true = 0
                d_false = abs(int(lhs) - int(rhs))
            else:
                d_true = 1
        if op == "Lt":
            value = int(lhs) < int(rhs)
            if value:
                d_false = int(rhs) - int(lhs)
            else:
                d_true = int(lhs) - int(rhs) + 1
        if op == "Gt":
            value = int(lhs) > int(rhs)
            if value:
                d_false = int(lhs) - int(rhs)
            else:
                d_true = int(rhs) - int(lhs) + 1
        if op == "Le":
            value = int(lhs) <= int(rhs)
            if value:
                d_false = int(rhs) - int(lhs) + 1
            else:
                d_true = int(lhs) - int(rhs)
        if op == "Ge":
            value = int(lhs) >= int(rhs)
            if value:
                d_false = int(lhs) - int(rhs)
            else:
                d_true = int(rhs) - int(lhs) + 1
    elif lhs.isascii() and rhs.isascii():
        if op == "Eq":
            value = ord(lhs) == ord(rhs)
            if value:
                d_true = 0
                d_false = 1
            else:
                d_true = abs(ord(lhs) - ord(rhs))
        if op == "Ne":
            value = ord(lhs) == ord(rhs)
            if value:
                d_true = 0
                d_false = abs(ord(lhs) - ord(rhs))
            else:
                d_true = 1
    else:
        if op == "In" or op == "in":
            d_0 = INFINITE
            if rhs == {}:
                d_true = sys.maxsize
                value = False
            else:
                for key, val in rhs:
                    d = abs(ord(key) - ord(lhs))
                    if d < d_0:
                        d_0 = d
                value = (d_0 == 0)
                if value:
                    d_false = 1
                else:
                    d_true = d_0

    update_maps(condition_num,d_true,d_false)
    return value
