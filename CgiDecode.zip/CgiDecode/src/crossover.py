from random import randint
from typing import List, Tuple


def crossover(parent1: List[str], parent2: List[str]) -> Tuple[List[str], List[str]]:
    offspring1 = None
    offspring2 = None
    # TODO: COMPLETAR
    return offspring1, offspring2
