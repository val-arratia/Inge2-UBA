#!./venv/bin/python
import unittest
from src.evaluate_condition import evaluate_condition


class TestEvaluateCondition(unittest.TestCase):
 #   def testExample(self):
 #       # TODO COMPLETAR
 #       evaluate_condition(1, "Eq", 10, 20)
 #       self.assertTrue(True)
 #       self.assertFalse(False)
  #      self.assertEqual(True, False)

    def test1(self):
        v = evaluate_condition(1, "Eq", "10", "20")
        self.assertFalse(v)
        v = evaluate_condition(1, "Eq", "20", "20")
        self.assertTrue(v)
        

